using System.Data;
using Microsoft.Data.SqlClient;
namespace RegristroClientes

{
    public partial class Form1 : Form
    {
        private string cadena ="Data Source = CAROLINA\\SQLEXPRESS; Initial Catalog = TBCLIENTES;Integrated Security = True;Encrypt=False";

        SqlConnection conexion;
        public Form1()
        {
            InitializeComponent();
            conexion = new SqlConnection(cadena);
        }

        private void MostrarClientes()
        {
            conexion.Open();
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM tbclientes", conexion);

            DataTable dt = new DataTable();

            da.Fill(dt);

            dgvClientes.DataSource = dt;

            conexion.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MostrarClientes();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text == "" ||
       txtTelefono.Text == "" ||
       txtCorreo.Text == "")
            {
                MessageBox.Show("Complete todos los campos");
                return;
            }

            conexion.Open();

            SqlCommand cmd = new SqlCommand(
                "INSERT INTO tbclientes(Nombre,Telefono,Correo) VALUES(@Nombre,@Telefono,@Correo)",
                conexion
            );

            cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text);
            cmd.Parameters.AddWithValue("@Telefono", txtTelefono.Text);
            cmd.Parameters.AddWithValue("@Correo", txtCorreo.Text);

            cmd.ExecuteNonQuery();

            conexion.Close();

            MessageBox.Show("Cliente guardado");

            MostrarClientes();

            txtNombre.Clear();
            txtTelefono.Clear();
            txtCorreo.Clear();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            MostrarClientes();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvClientes.CurrentRow == null)
            {
                MessageBox.Show("Seleccione un cliente");
                return;
            }

            int id = Convert.ToInt32(
                dgvClientes.CurrentRow.Cells[0].Value
            );

            conexion.Open();

            SqlCommand cmd = new SqlCommand(
                "DELETE FROM tbclientes WHERE Id=@Id",
                conexion
            );

            cmd.Parameters.AddWithValue("@Id", id);

            cmd.ExecuteNonQuery();

            conexion.Close();

            MessageBox.Show("Cliente eliminado");

            MostrarClientes();
        }
    }
}
