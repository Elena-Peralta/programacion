using Microsoft.Data.Sql;
using Microsoft.Data.SqlClient;
using System.Data;
namespace SistemasProductos
{
    public partial class Form1 : Form
    {
        private string cadena = "Data Source=CAROLINA\\SQLEXPRESS;Initial Catalog=Productos;Integrated Security=True;Encrypt=False";

        SqlConnection conexion;
        public Form1()
        {
            InitializeComponent();
            conexion = new SqlConnection(cadena);
        }
        private void MostrarProductos()
        {
            if (conexion.State == ConnectionState.Closed)
            {
                conexion.Open();
            }

            SqlDataAdapter da = new SqlDataAdapter(
                "SELECT * FROM productos",
                conexion
            );

            DataTable dt = new DataTable();

            da.Fill(dt);

            dgvProductos.DataSource = dt;

            conexion.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            conexion.Open();

            SqlCommand cmd = new SqlCommand(
                "INSERT INTO productos(Nombre,Precio,Stock) VALUES(@Nombre,@Precio,@Stock)",
                conexion
            );
            cmd.Parameters.AddWithValue("@Id", txtId.Text);
            cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text);
            cmd.Parameters.AddWithValue("@Precio", txtPrecio.Text);
            cmd.Parameters.AddWithValue("@Stock", txtStock.Text);

            cmd.ExecuteNonQuery();

            conexion.Close();

            MessageBox.Show("Producto guardado");

            MostrarProductos();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            MostrarProductos();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            conexion.Open();

            SqlDataAdapter da = new SqlDataAdapter(
                "SELECT * FROM productos WHERE Nombre LIKE @Nombre",
                conexion
            );

            da.SelectCommand.Parameters.AddWithValue(
                "@Nombre",
                "%" + txtBuscar.Text + "%"
            );

            DataTable dt = new DataTable();

            da.Fill(dt);

            dgvProductos.DataSource = dt;

            conexion.Close();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(
       dgvProductos.CurrentRow.Cells[0].Value
   );

            conexion.Open();

            SqlCommand cmd = new SqlCommand(
                "UPDATE productos SET Nombre=@Nombre, Precio=@Precio, Stock=@Stock WHERE Id=@Id",
                conexion
            );

            cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text);
            cmd.Parameters.AddWithValue("@Precio", txtPrecio.Text);
            cmd.Parameters.AddWithValue("@Stock", txtStock.Text);
            cmd.Parameters.AddWithValue("@Id", id);

            cmd.ExecuteNonQuery();

            conexion.Close();

            MessageBox.Show("Producto actualizado");

            MostrarProductos();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MostrarProductos();
        }

        private void dgvProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtId.Text = dgvProductos.CurrentRow.Cells[0].Value.ToString();
            txtNombre.Text = dgvProductos.CurrentRow.Cells[1].Value.ToString();
            txtPrecio.Text = dgvProductos.CurrentRow.Cells[2].Value.ToString();
            txtStock.Text = dgvProductos.CurrentRow.Cells[3].Value.ToString();
        }
    }
}
